from django.apps import AppConfig

class IsisDataAppConfig(AppConfig):
    name = 'isisdata'
    verbose_name = 'Isis Current Bibliography Data Manager'
