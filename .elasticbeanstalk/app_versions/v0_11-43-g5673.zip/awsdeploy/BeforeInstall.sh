cd /home/ec2-user/isiscb

rm -rf isiscb
